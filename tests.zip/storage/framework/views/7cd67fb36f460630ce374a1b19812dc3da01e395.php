create a new coupon
<?php /**PATH C:\Users\pc11\laravel's projects\coupon\resources\views/coupons/create.blade.php ENDPATH**/ ?>