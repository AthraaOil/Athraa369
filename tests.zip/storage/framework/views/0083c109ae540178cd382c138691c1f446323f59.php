    <?php echo e($coupon_code); ?>

<?php /**PATH C:\Users\pc11\laravel's projects\coupon\resources\views/coupons/index2.blade.php ENDPATH**/ ?>