create a new coupon
