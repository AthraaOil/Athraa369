{{-- @for ($scans as $scan)
    {{ $scan }}
@endfor --}}


Scan 2
