<?php

return [

    'city'                  => 'مدينة',
    'cities'                => 'المُدن',
    'name'                  => 'الأسم',
    'slug'                  => 'المفتاح',
    'country'               => 'الدولة',

    'select country'        => 'إختر الدولة',
    'select city'           => 'إختر المدينة',

    'create city'           => 'تم إضافة مدينة بنجاح',
    'update city'           => 'تم تحديث مدينة بنجاح',
    'delete city'           => 'تم حذف المدينة بنجاح',
    'delete question'       => 'هل أنت متاكد انك تريد الحذف ؟!',
    'force delete question' => 'هل أنت متاكد انك تريد حذف المدينة بشكل نهائي ؟!',
    'delete result'         => 'هذا الإجراء يتسسب بحذف المدينة بشكل نهائي',
    'restore city'          => 'تم إستعادة مدينة بنجاح',
    'force delete city'     => 'تم حذف المدينة بشكل نهائي بنجاح'

];
